String baseUrl = 'https://shamo-backend.buildwithangga.id/api';
var headerContent = {'Content-Type': 'application/json'};
