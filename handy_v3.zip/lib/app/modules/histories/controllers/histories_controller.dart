import 'package:get/get.dart';

class HistoriesController extends GetxController {
  //TODO: Implement HistoriesController

  final count = 0.obs;



  void increment() => count.value++;
}
