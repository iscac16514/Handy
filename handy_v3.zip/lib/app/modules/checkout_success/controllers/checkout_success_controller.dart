import 'package:get/get.dart';

class CheckoutSuccessController extends GetxController {
  //TODO: Implement CheckoutSuccessController

  final count = 0.obs;



  void increment() => count.value++;
}
